@echo off
:# OpenRSC. This file is FROZEN and deliberately tiny.
:#
:# It is the only part of the folder no update ever replaces, because it is the
:# part that does the replacing. cmd.exe re-reads a running .cmd by byte offset
:# as it executes, so rewriting one while it runs corrupts it - and PowerShell
:# holds its own script open for the same reason. So the updater stages the
:# launcher and itself as .new, and they are promoted HERE, at the top of the
:# next launch, when nothing is running.
:#
:# The real launcher is update\Launch.cmd. Everything interesting is there.
cd /d "%~dp0"

if exist "update\Launch.cmd.new"        move /y "update\Launch.cmd.new"        "update\Launch.cmd"        >nul
if exist "update\Update-Client.ps1.new" move /y "update\Update-Client.ps1.new" "update\Update-Client.ps1" >nul

if exist "update\Update-Client.ps1" (
  powershell -NoProfile -ExecutionPolicy Bypass -File "update\Update-Client.ps1"
) else (
  echo.
  echo  This folder has no updater in it, so it cannot bring itself up to date.
  echo  If the game refuses your login saying the client is out of date, you
  echo  need a fresh copy - ask for the download link.
  echo.
)

if not exist "update\Launch.cmd" (
  echo  update\Launch.cmd is missing. This folder is incomplete - get a fresh copy.
  pause
  exit /b 1
)
call "update\Launch.cmd"
exit /b %ERRORLEVEL%
