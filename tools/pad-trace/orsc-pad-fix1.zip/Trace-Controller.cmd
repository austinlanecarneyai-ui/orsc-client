@echo off
:# Plays AWS with the controller movement trace on.
:# Extract into your OpenRSC game folder (the one with Play-OpenRSC.cmd).
:# Your normal game files are not touched; this runs its own jar.
title OpenRSC - movement trace
cd /d "%~dp0"

if not exist "Open_RSC_Client-trace.jar" (
  echo  Open_RSC_Client-trace.jar is missing - extract the whole zip here.
  pause
  exit /b 1
)
if not exist "discord-rpc.jar" (
  echo  This is not the game folder: discord-rpc.jar is not here.
  echo  Extract the zip into the folder that has Play-OpenRSC.cmd in it.
  pause
  exit /b 1
)

set "JAVA=%~dp0update\jre\bin\java.exe"
if not exist "%JAVA%" set "JAVA=%~dp0jre\bin\java.exe"
if not exist "%JAVA%" set "JAVA=java"

echo  Tracing controller movement against the AWS world.
echo  Reproduce the bad walking, then close the game.
echo.
"%JAVA%" -Xms312m -Dsun.java2d.opengl=true -Dpad.trace=1 -Dpad.calibrate=1 -cp "Open_RSC_Client-trace.jar;discord-rpc.jar" orsc.OpenRSC > "pad-console.log" 2>&1

echo.
echo  Done. Send back the newest pad-trace log and pad-console.log:
dir /b /o-d pad-trace-*.log 2>nul
echo.
echo  They are in: %~dp0
explorer "%~dp0"
pause
