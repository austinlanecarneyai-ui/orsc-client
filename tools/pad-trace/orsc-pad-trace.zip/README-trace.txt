Controller movement trace (2026-10-10)

1. Extract everything in this zip into your OpenRSC game folder, the one
   with Play-OpenRSC.cmd in it. Nothing of yours is replaced.
2. Run Trace-Controller.cmd. It logs in to the AWS world as normal.
3. Make each problem happen a few times:
   - walking with the stick at the camera angles where it steps backwards
     (note roughly which way the camera was facing)
   - Catch mode (RT lock, LT catch) stepping backwards while chasing
   - chasing something with a tree or stump in the way until it gets stuck
4. Close the game. The folder opens; send back the newest
   pad-trace-<date>-<time>.log and pad-console.log.

Your normal Play-OpenRSC.cmd is unchanged and the updater ignores these
files. Delete Trace-Controller.cmd and Open_RSC_Client-trace.jar when done.
